<?php

namespace Drupal\webform\Element;

/**
 * Provides a webform custom composite element.
 *
 * @FormElement("webform_custom_composite")
 */
class WebformCustomComposite extends WebformMultiple {}

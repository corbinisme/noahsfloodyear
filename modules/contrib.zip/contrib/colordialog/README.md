# CKEDITOR COLOR DIALOG

## Installation

This module requires the core CKEditor module.

1. Download the plugin from <http://ckeditor.com/addon/colordialog> at least version 4.7.0.
2. Place the plugin in the root libraries folder (/libraries).
3. Enable CKEditor Color Dialog module in the Drupal admin.

## MAINTAINERS

- Dmitry Drozdik (ddrozdik) - <https://www.drupal.org/u/ddrozdik>
- Goran Miric (g_miric) - <https://www.drupal.org/u/g_miric>
